<br />
<b>Notice</b>:  Undefined variable: product_id in <b>/home/lichsugia.com/public_html/process_lsg.php</b> on line <b>134</b><br />
<br />
<b>Notice</b>:  Undefined variable: product_id in <b>/home/lichsugia.com/public_html/process_lsg.php</b> on line <b>145</b><br />
